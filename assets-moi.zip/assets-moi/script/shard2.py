from PIL import Image, ImageDraw
import os
W=16
def shard(n, base, light, dark, shadow, outline=(46,26,10,255), star=(255,72,48,255)):
    img=Image.new('RGBA',(W,W),(0,0,0,0)); d=ImageDraw.Draw(img)
    TOP=(8,1); UL=(4,5); LL=(5,11); BOT=(8,14); LR=(11,11); UR=(12,5)
    d.polygon([TOP,UL,(8,7)], fill=light)        # mặt trên trái
    d.polygon([TOP,UR,(8,7)], fill=dark)         # mặt trên phải
    d.polygon([UL,LL,BOT,(8,7)], fill=base)      # thân trái
    d.polygon([UR,LR,BOT,(8,7)], fill=shadow)    # thân phải
    px=img.load()
    for y in range(5,9):                         # vệt sáng dọc
        if px[6,y][3]: px[6,y]=light
    px[7,4]=light; px[6,4]=light
    filled={(x,y) for y in range(W) for x in range(W) if px[x,y][3]}
    for (x,y) in filled:                          # viền tối
        for dx,dy in((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)):
            nx,ny=x+dx,y+dy
            if 0<=nx<W and 0<=ny<W and (nx,ny) not in filled: px[nx,ny]=outline
    for (x,y) in [(9,9),(8,11),(10,7),(7,9),(9,12),(6,10),(10,10)][:n]:
        if px[x,y][3]: px[x,y]=star
    return img
def save(img,name):
    for s in (1,2,3,4):
        os.makedirs(f'x{s}',exist_ok=True)
        img.resize((W*s,W*s),Image.NEAREST).save(f'x{s}/{name}.png')
ramps=[((255,206,74),(255,248,210),(226,158,36),(168,104,22)),
       ((255,194,66),(255,244,198),(216,146,32),(158,94,20)),
       ((255,180,56),(255,238,184),(206,132,28),(148,84,18)),
       ((255,162,48),(255,232,168),(196,118,24),(138,74,16)),
       ((255,142,42),(255,226,152),(186,102,20),(128,64,14)),
       ((255,118,38),(255,218,138),(178,86,18),(118,54,12)),
       ((255,92,44),(255,208,130),(170,68,20),(108,46,12))]
for i,(b,l,dk,sh) in enumerate(ramps,1):
    save(shard(i,b+(255,),l+(255,),dk+(255,),sh+(255,)), f'manh-ky-uc-{i}')
from PIL import Image as I
im=[I.open(f'x4/manh-ky-uc-{i}.png') for i in (1,3,5,7)]
w=sum(i.width for i in im)+30; s=I.new('RGBA',(w,72),(32,32,38,255)); x=6
for i in im: s.paste(i,(x,4),i); x+=i.width+8
s.save('preview.png')
# xem cỡ thật 16px trên nền game
sm=I.open('x1/manh-ky-uc-4.png'); s2=I.new('RGBA',(64,64),(40,44,52,255)); s2.paste(sm.resize((16,16),I.NEAREST),(4,4),sm); s2.save('preview_16.png')
print('ok')
