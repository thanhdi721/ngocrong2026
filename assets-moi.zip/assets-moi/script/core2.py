from PIL import Image, ImageDraw
import os, math
W=16
def save(img,name):
    for s in (1,2,3,4):
        os.makedirs(f'x{s}',exist_ok=True)
        img.resize((W*s,W*s),Image.NEAREST).save(f'x{s}/{name}.png')

def void_core():
    C=(18,10,28,255); RING=(120,40,170,255); RIM=(190,78,240,255)
    CRACK=(236,128,255,255); HL=(255,240,255,255); OUT=(10,4,16,255)
    img=Image.new('RGBA',(W,W),(0,0,0,0)); d=ImageDraw.Draw(img)
    d.ellipse([2,2,13,13], fill=C); px=img.load()
    for y in range(W):
        for x in range(W):
            if px[x,y][3]:
                r=math.hypot(x-7.5,y-7.5)
                if r>5.0: px[x,y]=RIM
                elif r>4.2: px[x,y]=RING
    # vết nứt rò sáng, lệch tâm để không đối xứng
    for (x,y) in [(7,6),(8,7),(8,8),(7,9)]:
        if px[x,y][3]: px[x,y]=CRACK
    for (x,y) in [(9,6),(6,9),(9,9),(6,6)]:
        if px[x,y][3]: px[x,y]=RING
    px[5,4]=HL   # điểm sáng trên trái
    filled={(x,y) for y in range(W) for x in range(W) if px[x,y][3]}
    for (x,y) in filled:
        for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
            nx,ny=x+dx,y+dy
            if 0<=nx<W and 0<=ny<W and (nx,ny) not in filled: px[nx,ny]=OUT
    for (x,y) in [(3,2),(13,6),(4,13)]: px[x,y]=HL   # tia lẻ
    return img

def empty_shell():
    SH=(86,84,98,255); LT=(150,148,164,255); DK=(58,56,70,255); OUT=(26,24,34,255)
    img=Image.new('RGBA',(W,W),(0,0,0,0)); d=ImageDraw.Draw(img)
    d.ellipse([2,2,13,13], fill=SH); px=img.load()
    for y in range(W):
        for x in range(W):
            if px[x,y][3]:
                t=(x-2)/11*0.5+(y-2)/11*0.8
                px[x,y]= LT if t<0.35 else (SH if t<0.75 else DK)
    d.ellipse([5,5,10,10], fill=(0,0,0,0))          # ruột rỗng
    for (x,y) in [(7,2),(7,3),(8,4),(4,10),(5,11),(11,9)]:   # vết nứt
        if px[x,y][3]: px[x,y]=DK
    filled={(x,y) for y in range(W) for x in range(W) if px[x,y][3]}
    for (x,y) in filled:
        for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
            nx,ny=x+dx,y+dy
            if 0<=nx<W and 0<=ny<W and (nx,ny) not in filled: px[nx,ny]=OUT
    return img

save(void_core(),'loi-hu-khong'); save(empty_shell(),'vo-loi-rong')
from PIL import Image as I
im=[I.open(f'x4/{n}.png') for n in ('manh-ky-uc-7','loi-hu-khong','vo-loi-rong')]
s=I.new('RGBA',(3*72+8,80),(32,32,38,255)); x=8
for i in im: s.paste(i,(x,8),i); x+=72
s.save('preview_core.png'); print('ok')
