#!/usr/bin/env python3
"""9 icon pixel art chuẩn Ngọc Rồng Online — 16×16, nearest-neighbor → x1..x4.

Thiết kế:
  manh-ky-uc-1..7  = mảnh cầu bóng (gợi Ngọc Rồng vỡ) + N sao đỏ, vàng→cam đỏ
  loi-hu-khong     = cầu hư không đen + vành tím + nứt sáng
  vo-loi-rong      = vỏ xám kim loại rỗng, nứt
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ICON = ROOT / "icon"
W = 16


def C(h: str, a: int = 255) -> tuple[int, int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a


def outline(img: Image.Image, color, diag=True) -> None:
    px = img.load()
    filled = {(x, y) for y in range(W) for x in range(W) if px[x, y][3]}
    nbs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    if diag:
        nbs += ((1, 1), (-1, -1), (1, -1), (-1, 1))
    for x, y in filled:
        for dx, dy in nbs:
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < W and (nx, ny) not in filled:
                px[nx, ny] = color


def save_scales(img: Image.Image, name: str) -> None:
    for s in (1, 2, 3, 4):
        d = ICON / f"x{s}"
        d.mkdir(parents=True, exist_ok=True)
        img.resize((W * s, W * s), Image.NEAREST).save(d / f"{name}.png")


# Palette đo gần icon 419: outline nâu, highlight kem, base hổ phách, sao đỏ
# (base, hl, mid, shade, deep, outline, star)
# Giữ vàng/cam sáng (không tối nâu) để sao đỏ luôn nổi — như Ngọc Rồng thật
RAMPS = [
    ("#F0C050", "#FFF8E0", "#E8A830", "#C88820", "#8A5820", "#5A3010", "#E01810"),
    ("#F0B448", "#FFF4D4", "#E09C28", "#C07C18", "#845018", "#582C10", "#E01810"),
    ("#F0A840", "#FFF0C8", "#D89020", "#B47014", "#7A4814", "#50280C", "#E01810"),
    ("#F09834", "#FFE8B8", "#D08418", "#A86410", "#704010", "#48240A", "#E01010"),
    ("#F08828", "#FFE0A8", "#C87814", "#985810", "#68380C", "#402008", "#E00810"),
    ("#F07420", "#FFD898", "#C06814", "#904C0C", "#60300C", "#381808", "#F00810"),
    ("#F06018", "#FFD088", "#B85810", "#88400C", "#58280A", "#301008", "#FF0810"),
]


def draw_shard(n: int) -> Image.Image:
    """Mảnh Ngọc Rồng vỡ: silhouette răng cưa + shading cầu bóng."""
    base, hl, mid, shade, deep, out, star = (C(x) for x in RAMPS[n - 1])
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Silhouette mảnh: đỉnh nhọn, thân phình, cạnh phải răng cưa, đáy nhọn
    # (nhìn rõ là MẢNH, không nhầm Ngọc Rồng nguyên)
    shape = [
        (8, 1),   # đỉnh
        (4, 3),
        (2, 6),
        (3, 10),
        (5, 13),
        (8, 14),  # đáy
        (10, 12),
        (13, 10), # răng phải
        (11, 8),
        (13, 6),
        (11, 4),
        (10, 2),
    ]
    d.polygon(shape, fill=base)
    px = img.load()
    cx, cy = 7.0, 7.0

    for y in range(W):
        for x in range(W):
            if not px[x, y][3]:
                continue
            r = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            # Shading giả cầu (sáng trên-trái → tối dưới-phải)
            if x <= 4 and y <= 4:
                px[x, y] = hl
            elif x <= 6 and y <= 6:
                px[x, y] = mid
            elif x >= 10 or y >= 11:
                px[x, y] = deep
            elif x >= 9 or y >= 9:
                px[x, y] = shade
            elif r > 5.5:
                px[x, y] = shade
            else:
                px[x, y] = base

    # Specular trắng (chuẩn Ngọc Rồng)
    for x, y in ((4, 3), (5, 3), (4, 4)):
        if px[x, y][3]:
            px[x, y] = hl
    if px[5, 4][3]:
        px[5, 4] = C("#FFFFFF")

    # Vết nứt
    for x, y in ((7, 5), (8, 6), (7, 8), (9, 7)):
        if px[x, y][3]:
            px[x, y] = mid

    outline(img, out, diag=False)

    # Sao đỏ — cụm giữa, số = N
    layouts = {
        1: [(7, 7)],
        2: [(6, 6), (8, 8)],
        3: [(7, 5), (6, 8), (8, 8)],
        4: [(6, 5), (8, 5), (6, 8), (8, 8)],
        5: [(7, 4), (5, 6), (7, 7), (9, 6), (7, 9)],
        6: [(6, 4), (8, 4), (5, 7), (9, 7), (6, 10), (8, 10)],
        7: [(7, 3), (5, 5), (9, 5), (7, 7), (5, 9), (9, 9), (7, 11)],
    }
    star_set = set(layouts[n])
    for sx, sy in layouts[n]:
        if 0 <= sx < W and 0 <= sy < W and px[sx, sy][3]:
            px[sx, sy] = star
            if n <= 2 and (sx, sy) == layouts[n][0]:
                for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                    nx, ny = sx + dx, sy + dy
                    if 0 <= nx < W and 0 <= ny < W and px[nx, ny][3] and (nx, ny) not in star_set:
                        px[nx, ny] = C("#A01010")

    return img


def draw_void_core() -> Image.Image:
    """Cầu hư không — đen + vành tím + nứt magenta + tia orbit."""
    core, mid, ring, rim, glow, spark, out = (
        C("#0C0614"), C("#241038"), C("#7828B8"), C("#C060F0"),
        C("#F090FF"), C("#FFF8FF"), C("#080410"),
    )
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([2, 2, 13, 13], fill=core)
    px = img.load()
    cx, cy = 7.5, 7.5

    for y in range(W):
        for x in range(W):
            if not px[x, y][3]:
                continue
            r = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if r > 5.3:
                px[x, y] = rim
            elif r > 4.4:
                px[x, y] = ring
            elif r > 3.0:
                px[x, y] = mid
            # highlight vành trên-trái
            if r > 4.0 and x <= 5 and y <= 5:
                px[x, y] = glow

    # Nứt rò sáng (chữ X lệch)
    for x, y in (
        (7, 5), (7, 6), (8, 7), (8, 8), (7, 9), (6, 8),
        (9, 6), (6, 6), (9, 9), (6, 9), (7, 7),
    ):
        if px[x, y][3]:
            px[x, y] = glow
    px[7, 7] = spark

    outline(img, out, diag=False)

    # Tia orbit
    for x, y in ((2, 3), (13, 4), (14, 8), (3, 13), (11, 13), (1, 9)):
        if 0 <= x < W and 0 <= y < W:
            px[x, y] = spark if (x + y) % 2 else glow

    return img


def draw_empty_shell() -> Image.Image:
    """Vỏ lõi rỗng — cầu xám kim loại, lỗ giữa, nứt."""
    hl, mid, shade, deep, crack, out = (
        C("#D0CCD8"), C("#9090A0"), C("#585868"), C("#303038"),
        C("#181820"), C("#101018"),
    )
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([2, 2, 13, 13], fill=mid)
    px = img.load()
    cx, cy = 7.5, 7.5

    for y in range(W):
        for x in range(W):
            if not px[x, y][3]:
                continue
            t = (x - 2) / 11 * 0.4 + (y - 2) / 11 * 0.9
            r = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if t < 0.25:
                px[x, y] = hl
            elif t < 0.5:
                px[x, y] = mid
            elif t < 0.75:
                px[x, y] = shade
            else:
                px[x, y] = deep
            # vành trong tối trước khi khoét
            if 2.6 < r < 3.8:
                px[x, y] = shade if t < 0.5 else deep

    # Lỗ rỗng
    d.ellipse([5, 5, 10, 10], fill=(0, 0, 0, 0))

    # Nứt vỏ
    for x, y in ((7, 2), (8, 3), (8, 4), (4, 9), (4, 10), (5, 11), (11, 8), (11, 9), (10, 10)):
        if px[x, y][3]:
            px[x, y] = crack

    # Specular kim loại
    for x, y in ((4, 3), (5, 3), (4, 4)):
        if px[x, y][3]:
            px[x, y] = C("#F0F0F8")

    outline(img, out, diag=False)
    return img


def make_preview(names: list[str]) -> None:
    imgs = [Image.open(ICON / "x4" / f"{n}.png") for n in names]
    pad, gap = 8, 10
    w = pad * 2 + sum(i.width for i in imgs) + gap * (len(imgs) - 1)
    sheet = Image.new("RGBA", (w, 80), (36, 38, 46, 255))
    x = pad
    for im in imgs:
        sheet.paste(im, (x, 8), im)
        x += im.width + gap
    sheet.save(ROOT / "preview.png")

    # So với Ngọc Rồng thật
    src = ROOT.parent / "SRC" / "data" / "icon" / "x4"
    row = []
    for rid in (419, 422, 425):
        p = src / f"{rid}.png"
        if p.exists():
            row.append(Image.open(p).convert("RGBA").resize((64, 64), Image.NEAREST))
    row += [Image.open(ICON / "x4" / f"manh-ky-uc-{i}.png") for i in (1, 4, 7)]
    row += [
        Image.open(ICON / "x4" / "loi-hu-khong.png"),
        Image.open(ICON / "x4" / "vo-loi-rong.png"),
    ]
    w = pad * 2 + sum(i.width for i in row) + 8 * (len(row) - 1)
    sheet = Image.new("RGBA", (w, 80), (28, 28, 34, 255))
    x = pad
    for im in row:
        sheet.paste(im, (x, 8), im)
        x += im.width + 8
    sheet.save(ROOT / "preview-co-that.png")


def main() -> None:
    names = []
    for i in range(1, 8):
        name = f"manh-ky-uc-{i}"
        save_scales(draw_shard(i), name)
        names.append(name)
    save_scales(draw_void_core(), "loi-hu-khong")
    save_scales(draw_empty_shell(), "vo-loi-rong")
    names += ["loi-hu-khong", "vo-loi-rong"]
    make_preview(names)
    print(f"OK 9 icon × 4 → {ICON}")


if __name__ == "__main__":
    main()
